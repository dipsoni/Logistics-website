const https = require('https');

function formatRecipientNumber(phone) {
  if (!phone) return '+919274508210';
  let clean = phone.replace(/[\s\-\(\)]/g, '');
  if (/^[6-9]\d{9}$/.test(clean)) {
    return '+91' + clean;
  }
  if (/^91[6-9]\d{9}$/.test(clean)) {
    return '+' + clean;
  }
  return clean;
}

function isValidIndianMobile(mobile) {
  const cleanMobile = mobile.replace(/[\s\-\(\)]/g, '');
  return /^(?:\+91|91|0)?[6-9]\d{9}$/.test(cleanMobile);
}

function sendWhatsAppMessage(toPhone, messageText) {
  return new Promise((resolve) => {
    const provider = (process.env.WHATSAPP_PROVIDER || 'callmebot').toLowerCase();
    const formattedPhone = formatRecipientNumber(toPhone);

    if (provider === 'callmebot') {
      const apiKey = process.env.CALLMEBOT_API_KEY;
      if (!apiKey || apiKey.includes('your_')) {
        return resolve({ success: false, provider: 'callmebot', error: 'CALLMEBOT_API_KEY not configured.' });
      }

      const encodedText = encodeURIComponent(messageText);
      const requestUrl = `https://api.callmebot.com/whatsapp.php?phone=${encodeURIComponent(formattedPhone)}&text=${encodedText}&apikey=${encodeURIComponent(apiKey)}`;

      https.get(requestUrl, (res) => {
        let responseData = '';
        res.on('data', chunk => responseData += chunk);
        res.on('end', () => {
          const lower = responseData.toLowerCase();
          const isOk = res.statusCode >= 200 && res.statusCode < 300 && !lower.includes('invalid') && !lower.includes('error');
          resolve({
            success: isOk,
            provider: 'callmebot',
            statusCode: res.statusCode,
            error: isOk ? null : responseData.trim()
          });
        });
      }).on('error', (err) => {
        resolve({ success: false, provider: 'callmebot', error: err.message });
      });
    } else {
      resolve({ success: false, provider, error: `Provider ${provider} not configured.` });
    }
  });
}

exports.handler = async function(event, context) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 450, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const { name, mobile } = body;

    if (!name || name.trim().length < 2) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Please enter your full name (at least 2 characters).' })
      };
    }

    if (!mobile || !isValidIndianMobile(mobile)) {
      return {
        statusCode: 400,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Please enter a valid 10-digit Indian mobile number.' })
      };
    }

    const recipientNumber = process.env.MY_MOBILE_NUMBER || '8849915522';
    const now = new Date();
    const formattedDate = now.toLocaleString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });

    const inquiryRecord = {
      id: 'INQ-' + Date.now(),
      name: name.trim(),
      mobile: mobile.trim(),
      timestamp: now.toISOString(),
      formattedDate: formattedDate
    };

    const whatsappMessage = `🔔 New Customer Inquiry\n\nName: ${inquiryRecord.name}\nMobile: ${inquiryRecord.mobile}\nTime: ${formattedDate}`;

    const whatsappResult = await sendWhatsAppMessage(recipientNumber, whatsappMessage);

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        message: 'Thank you! We have received your inquiry. We will contact you shortly.',
        whatsappDelivery: whatsappResult
      })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Internal server error: ' + err.message })
    };
  }
};
